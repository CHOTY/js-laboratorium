// =============================================
//  ÚLOHA: Akordeón na stránke Q&A
// =============================================
//
// Odpovede (.panel) sú na začiatku skryté. Po kliknutí na otázku (.acc)
// sa má odpoveď zobraziť, po ďalšom kliknutí znova skryť.
//
// 1. Nájdi všetky otázky (.acc) pomocou querySelectorAll.
// 2. Vypíš do konzoly, koľko otázok si našiel/našla.
// 3. Každej otázke pridaj addEventListener("click", ...).
// 4. Po kliknutí prepni na odpovedi triedu "otvoreny".
//      odpoveď je prvok hneď za otázkou:  otazka.nextElementSibling
//      triedu prepneš:                    classList.toggle("otvoreny")
// 5. Bonus: na otázke prepínaj triedu "aktivna" (zmení sa + na −).
//
// CSS triedy .otvoreny a .aktivna sú už pripravené v css/style.css.

