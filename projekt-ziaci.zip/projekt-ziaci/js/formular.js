// =============================================
//  CVIČENIE z JS 1: kontrola registračného formulára
// =============================================
//
// Po kliknutí na „Registrovať“ skontroluj:
//   - meno – nesmie byť prázdne
//   - vek – aspoň 18
//   - e-mail – nesmie byť prázdny a musí mať správny tvar
//   - heslo – nesmie byť prázdne, aspoň 8 znakov,
//             aspoň 1 malé písmeno, 1 veľké písmeno a 1 číslo
//   - zopakované heslo – musí sa zhodovať s heslom
//   - checkbox GDPR – musí byť zaškrtnutý
//
// O chybách informuj používateľa cez alert.
// Ak je všetko v poriadku, presmeruj ho na stránku dakujem.html.
//
// Tipy:
//   formular.addEventListener("submit", function (event) {
//     event.preventDefault();   // zastaví odoslanie formulára
//     ...
//   });
//   hodnota inputu:      document.getElementById("meno").value
//   zaškrtnutý checkbox: document.getElementById("gdpr").checked
//   číslo z inputu:      Number(document.getElementById("vek").value)
//   presmerovanie:       window.location.href = "dakujem.html";

const formular = document.getElementById("registracia");

