// =============================================
//  ÚLOHA: Doprogramuj kalkulačku
// =============================================
// Funkcie sa volajú z HTML cez atribút onclick, napr. onclick="display('7')".
// Displej je <input> s id="result" – jeho obsah je vo vlastnosti .value

// display(hodnota) – pridá stlačený znak na koniec displeja
function display(hodnota) {
  // TODO
}

// clearAll() – vymaže displej
function clearAll() {
  // TODO
}

// solve() – vypočíta príklad na displeji a zobrazí výsledok
function solve() {
  // TODO
}
