// =============================================
//  JavaScript 2 – Manipulácia s DOM
//  Tento súbor načítava index.html.
//  Výsledok sleduj v prehliadači: F12 → Konzola / Prieskumník
// =============================================

// 1. Pridávanie elementov – createElement, append


// 2. Pridávanie obsahu – innerText, textContent, innerHTML


// 3. Získavanie obsahu


// 4. Mazanie elementov – remove


// 5. Atribúty – setAttribute, getAttribute, removeAttribute


// 6. Triedy – classList.add, remove, toggle, contains


// 7. Štýly – element.style.vlastnost = "hodnota"
