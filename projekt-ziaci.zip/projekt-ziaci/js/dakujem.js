// Formulár môže poslať meno v adrese stránky: dakujem.html?meno=Jana
const parametre = new URLSearchParams(window.location.search);
const meno = parametre.get("meno");

if (meno) {
  // textContent – meno od používateľa vkladáme bezpečne, nie cez innerHTML
  document.getElementById("pozdrav").textContent = "Ďakujeme, " + meno + "!";
}

document.getElementById("spat").addEventListener("click", function () {
  window.location.href = "formular.html";
});
